-- PostgreSQL Schema for Gateway-Controller API Configurations
-- Version: 6

-- Base table for all artifact types
CREATE TABLE IF NOT EXISTS artifacts (
    uuid TEXT NOT NULL,
    gateway_id TEXT NOT NULL,
    display_name TEXT NOT NULL,
    version TEXT NOT NULL,
    data_version TEXT NOT NULL DEFAULT '1.0',
    kind TEXT NOT NULL,
    handle TEXT NOT NULL,
    desired_state TEXT NOT NULL CHECK(desired_state IN ('deployed', 'undeployed')),
    deployment_id TEXT,
    origin TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    deployed_at TIMESTAMPTZ,
    -- NEW COLUMNS: cp_sync_status, cp_artifact_id and cp_sync_info must be added 
    -- to existing deployments via ALTER TABLE migration.
    cp_sync_status  TEXT CHECK(cp_sync_status IN ('pending', 'success', 'failed')),
    cp_sync_info    TEXT,
    cp_artifact_id  TEXT,
    PRIMARY KEY (gateway_id, uuid),
    UNIQUE(gateway_id, kind, display_name, version),
    UNIQUE(gateway_id, kind, handle)
);
CREATE INDEX IF NOT EXISTS idx_artifacts_cp_artifact_id ON artifacts(gateway_id, cp_artifact_id) WHERE cp_artifact_id IS NOT NULL;

-- Per-resource-type tables

CREATE TABLE IF NOT EXISTS rest_apis (
    uuid TEXT NOT NULL,
    gateway_id TEXT NOT NULL,
    configuration TEXT NOT NULL,
    PRIMARY KEY (gateway_id, uuid),
    FOREIGN KEY(gateway_id, uuid) REFERENCES artifacts(gateway_id, uuid) ON DELETE CASCADE
);

-- Note: websub_apis, webbroker_apis, and webhook_secrets tables are NOT defined
-- here. They are event-gateway-specific and owned by the event-gateway-controller
-- module (event-gateway/gateway-controller/pkg/dbschema), which applies its own
-- supplemental DDL against this same database at startup.

CREATE TABLE IF NOT EXISTS llm_providers (
    uuid TEXT NOT NULL,
    gateway_id TEXT NOT NULL,
    configuration TEXT NOT NULL,
    PRIMARY KEY (gateway_id, uuid),
    FOREIGN KEY(gateway_id, uuid) REFERENCES artifacts(gateway_id, uuid) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS llm_proxies (
    uuid TEXT NOT NULL,
    gateway_id TEXT NOT NULL,
    configuration TEXT NOT NULL,
    provider_uuid TEXT NOT NULL,
    PRIMARY KEY (gateway_id, uuid),
    FOREIGN KEY(gateway_id, uuid) REFERENCES artifacts(gateway_id, uuid) ON DELETE CASCADE,
    FOREIGN KEY(gateway_id, provider_uuid) REFERENCES llm_providers(gateway_id, uuid) ON DELETE RESTRICT
);

CREATE TABLE IF NOT EXISTS mcp_proxies (
    uuid TEXT NOT NULL,
    gateway_id TEXT NOT NULL,
    configuration TEXT NOT NULL,
    PRIMARY KEY (gateway_id, uuid),
    FOREIGN KEY(gateway_id, uuid) REFERENCES artifacts(gateway_id, uuid) ON DELETE CASCADE
);

-- A2A Agents table (added in schema version 5)
CREATE TABLE IF NOT EXISTS agents (
    uuid TEXT NOT NULL,
    gateway_id TEXT NOT NULL,
    configuration TEXT NOT NULL,
    -- Signed public Agent Card, produced by the controller at deploy time.
    -- NULL when signing is disabled, or in passthrough mode. Persisted rather
    -- than recomputed: signatures are produced only on deploy, never at startup.
    signed_public_card TEXT,
    -- Signed protected (extended) Agent Card, on the same terms as the public
    -- one above. The two representations are validated, stored, and signed
    -- independently, so an Agent may have either, both, or neither. Nothing
    -- writes this column until card signing lands; the protected card itself
    -- ships unsigned in its managed representation's configuration.
    signed_protected_card TEXT,
    PRIMARY KEY (gateway_id, uuid),
    FOREIGN KEY(gateway_id, uuid) REFERENCES artifacts(gateway_id, uuid) ON DELETE CASCADE
);

-- GraphQL is not a separate product the way event-gateway is (see the websub_apis/
-- webbroker_apis note above), so graphql_apis is defined directly here as a
-- one-column-identical clone of rest_apis, instead of being owned by a separate
-- supplemental-DDL module.
CREATE TABLE IF NOT EXISTS graphql_apis (
    uuid TEXT NOT NULL,
    gateway_id TEXT NOT NULL,
    configuration TEXT NOT NULL,
    PRIMARY KEY (gateway_id, uuid),
    FOREIGN KEY(gateway_id, uuid) REFERENCES artifacts(gateway_id, uuid) ON DELETE CASCADE
);

-- Table for custom TLS certificates
CREATE TABLE IF NOT EXISTS certificates (
    uuid TEXT NOT NULL,
    gateway_id TEXT NOT NULL,
    name TEXT NOT NULL,
    certificate BYTEA NOT NULL,
    subject TEXT NOT NULL,
    issuer TEXT NOT NULL,
    not_before TIMESTAMPTZ NOT NULL,
    not_after TIMESTAMPTZ NOT NULL,
    cert_count INTEGER NOT NULL DEFAULT 1,
    -- NEW COLUMNS: usage, role, match_json, private_key_ciphertext and
    -- key_algorithm must be added to existing deployments via the guarded
    -- ALTER TABLE statements below (idempotent, safe to re-run). usage
    -- separates backend/upstream trust, a pooled client certificate
    -- authority (mTLS), and (usage: identity) a gateway identity — a
    -- certificate chain plus its encrypted private key presented to a
    -- backend requiring mutual TLS on outbound connections; the three
    -- purposes never share a trust bundle. role client and relay apply to
    -- usage: downstream, and role default to usage: identity.
    -- private_key_ciphertext/key_algorithm only apply to usage: identity and
    -- stay NULL for every other usage.
    usage TEXT NOT NULL DEFAULT 'upstream',
    role TEXT NOT NULL DEFAULT 'client',
    -- match_json narrows a role: relay entry to the connections it vouches
    -- for (JSON-encoded {"dnsSANs": [...], "uriSANs": [...]}); NULL means
    -- unnarrowed. Only meaningful for role: relay.
    match_json TEXT,
    private_key_ciphertext TEXT,
    key_algorithm TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (gateway_id, uuid),
    UNIQUE(gateway_id, name)
);
-- Upgrade path for already-provisioned databases (CREATE TABLE IF NOT EXISTS
-- above is a no-op against them): add the columns if this table pre-dates them.
ALTER TABLE certificates ADD COLUMN IF NOT EXISTS usage TEXT NOT NULL DEFAULT 'upstream';
ALTER TABLE certificates ADD COLUMN IF NOT EXISTS role TEXT NOT NULL DEFAULT 'client';
ALTER TABLE certificates ADD COLUMN IF NOT EXISTS match_json TEXT;
ALTER TABLE certificates ADD COLUMN IF NOT EXISTS private_key_ciphertext TEXT;
ALTER TABLE certificates ADD COLUMN IF NOT EXISTS key_algorithm TEXT;

-- LLM Provider Templates table
CREATE TABLE IF NOT EXISTS llm_provider_templates (
    uuid TEXT NOT NULL,
    gateway_id TEXT NOT NULL,
    handle TEXT NOT NULL,
    configuration TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (gateway_id, uuid),
    UNIQUE(gateway_id, handle)
);

-- Table for API keys
CREATE TABLE IF NOT EXISTS api_keys (
    uuid TEXT NOT NULL,
    gateway_id TEXT NOT NULL,
    name TEXT NOT NULL,
    api_key TEXT NOT NULL,
    masked_api_key TEXT NOT NULL,
    artifact_uuid TEXT NOT NULL,
    status TEXT NOT NULL CHECK(status IN ('active', 'revoked', 'expired')) DEFAULT 'active',
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    created_by TEXT NOT NULL DEFAULT 'system',
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    expires_at TIMESTAMPTZ NULL,
    source TEXT NOT NULL DEFAULT 'local',
    external_ref_id TEXT NULL,
    issuer TEXT NULL DEFAULT NULL,
    UNIQUE (gateway_id, artifact_uuid, name),
    UNIQUE (gateway_id, uuid),
    PRIMARY KEY (gateway_id, api_key)
);

CREATE INDEX IF NOT EXISTS idx_api_key_status ON api_keys(status);
CREATE INDEX IF NOT EXISTS idx_created_by ON api_keys(created_by);

-- Subscription plans table (organization-scoped rate/billing plans)
CREATE TABLE IF NOT EXISTS subscription_plans (
    uuid TEXT NOT NULL,
    gateway_id TEXT NOT NULL,
    plan_name TEXT NOT NULL,
    billing_plan TEXT,
    stop_on_quota_reach BOOLEAN DEFAULT TRUE,
    throttle_limit_count INTEGER,
    throttle_limit_unit TEXT,
    expiry_time TIMESTAMPTZ,
    status TEXT NOT NULL CHECK(status IN ('ACTIVE', 'INACTIVE')) DEFAULT 'ACTIVE',
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (gateway_id, uuid),
    UNIQUE(gateway_id, plan_name)
);

-- Subscriptions table (application-level subscriptions for REST APIs, even before deployment)
-- subscription_token_hash: for xDS validation and request validation (Platform-API stores original token)
CREATE TABLE IF NOT EXISTS subscriptions (
    uuid TEXT NOT NULL,
    gateway_id TEXT NOT NULL,
    api_id TEXT NOT NULL,
    application_id TEXT,
    subscription_token_hash TEXT NOT NULL,
    subscription_plan_id TEXT,
    -- NEW COLUMNS: billing_customer_id and billing_subscription_id must be added
    -- to existing deployments via ALTER TABLE migration.
    billing_customer_id TEXT,
    billing_subscription_id TEXT,
    status TEXT NOT NULL CHECK(status IN ('ACTIVE', 'INACTIVE', 'REVOKED')) DEFAULT 'ACTIVE',
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (gateway_id, uuid),
    FOREIGN KEY (gateway_id, subscription_plan_id) REFERENCES subscription_plans(gateway_id, uuid),
    UNIQUE(gateway_id, api_id, subscription_token_hash)
);
CREATE INDEX IF NOT EXISTS idx_subscriptions_application_id ON subscriptions(application_id);

-- Table for gateway states (used by eventhub for multi-replica sync)
CREATE TABLE IF NOT EXISTS gateway_states (
    gateway_id TEXT PRIMARY KEY,
    version_id TEXT NOT NULL DEFAULT '',
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Table for events (used by eventhub for multi-replica sync)
CREATE TABLE IF NOT EXISTS events (
    gateway_id TEXT NOT NULL,
    processed_timestamp TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    originated_timestamp TIMESTAMPTZ NOT NULL,
    entity_type TEXT NOT NULL,
    action TEXT NOT NULL CHECK(action IN ('CREATE', 'UPDATE', 'DELETE')),
    entity_id TEXT NOT NULL,
    event_id TEXT NOT NULL,
    event_data TEXT NOT NULL,
    PRIMARY KEY (gateway_id, event_id),
    FOREIGN KEY (gateway_id) REFERENCES gateway_states(gateway_id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_events_gateway_id_processed_timestamp ON events(gateway_id, processed_timestamp);
-- Applications
CREATE TABLE IF NOT EXISTS applications (
    application_uuid TEXT NOT NULL,
    gateway_id TEXT NOT NULL,
    application_id TEXT NOT NULL,
    application_name TEXT NOT NULL,
    application_type TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (gateway_id, application_uuid)
);
-- Application to API key mappings
CREATE TABLE IF NOT EXISTS application_api_keys (
    application_uuid TEXT NOT NULL,
    api_key_id TEXT NOT NULL,
    gateway_id TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (gateway_id, application_uuid, api_key_id),
    FOREIGN KEY (gateway_id, application_uuid) REFERENCES applications(gateway_id, application_uuid) ON DELETE CASCADE,
    FOREIGN KEY (gateway_id, api_key_id) REFERENCES api_keys(gateway_id, uuid) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_app_api_keys_apikey ON application_api_keys(gateway_id, api_key_id);

-- Table for encrypted secrets (gateway_id + handle form the composite PK)
-- provider and key_version are self-describing inside the ciphertext envelope
CREATE TABLE IF NOT EXISTS secrets (
    gateway_id TEXT NOT NULL,
    handle TEXT NOT NULL,
    display_name TEXT NOT NULL,
    description TEXT,
    ciphertext BYTEA NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (gateway_id, handle)
);

-- Note: webhook_secrets (per-API HMAC secrets for the websub-hmac-auth policy)
-- is also owned by event-gateway/gateway-controller/pkg/dbschema — see note above.
